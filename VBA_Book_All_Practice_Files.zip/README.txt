Microsoft Excel VBA & Macros - From Beginner to Advanced
by Pushp Raj

All companion practice files, Parts I-V (Chapters 1-53)

Part_I   - Chapters 1-9  (Volume 1): VBA_Book_Practice_Part1.xlsx,
           VBA_Book_Ch09_Supplier_Prices.xlsx and a README
Part_II  - Chapters 10-20 (Volume 2): VBA_Book_Practice_Part2.xlsx and a README
Part_III - Chapters 21-30 (Volume 3): VBA_Book_Practice_Part3.xlsx and a README
Part_IV  - Chapters 31-40 (Volume 4): VBA_Book_Practice_Part4.xlsx, Branches and CSV folders,
           and a README. Save chapter workbooks inside Part_IV.
Part_V   - Chapters 41-53 (Volume 5): VBA_Book_Practice_Part5.xlsx, a Templates folder
           and a README. Save chapter workbooks inside Part_V.

All data in these files is ILLUSTRATIVE and invented for teaching.
It does not represent any real company, person or transaction.

Before adding code to a workbook: File > Save As > Excel Macro-Enabled
Workbook (*.xlsm). Keep the downloaded .xlsx files as clean originals.
