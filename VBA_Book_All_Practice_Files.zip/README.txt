Microsoft Excel VBA & Macros - From Beginner to Advanced
by Pushp Raj

All companion practice files, Parts I-II (Chapters 1-20)

Part_I   - Chapters 1-9  (Volume 1): VBA_Book_Practice_Part1.xlsx,
           VBA_Book_Ch09_Supplier_Prices.xlsx and a README
Part_II  - Chapters 10-20 (Volume 2): VBA_Book_Practice_Part2.xlsx and a README

All data in these files is ILLUSTRATIVE and invented for teaching.
It does not represent any real company, person or transaction.

Before adding code to a workbook: File > Save As > Excel Macro-Enabled
Workbook (*.xlsm). Keep the downloaded .xlsx files as clean originals.
