Microsoft Excel VBA & Macros - From Beginner to Advanced
Companion practice files for Part III (Chapters 21-30)

All data in these files is ILLUSTRATIVE and invented for teaching.
It does not represent any real company, person or transaction.

VBA_Book_Practice_Part3.xlsx
  Used in Chapters 21-30. Sheets: ReadMe, Orders (48 Q3 orders with Line Total
  formulas), Products, Targets, Settings, Branches (a gap and a note below the data),
  PriceCheck (one code that does not exist) and Report (blank, for output).
  Before adding code: File > Save As > Excel Macro-Enabled Workbook (*.xlsm),
  for example Chapter25.xlsm, so every chapter starts from the same data.

Check figures: Orders total Rs 658,324.00 from 255 units (12 orders per region);
6 orders of Rs 25,000 or more; 2 cancelled orders (quantity 0).
