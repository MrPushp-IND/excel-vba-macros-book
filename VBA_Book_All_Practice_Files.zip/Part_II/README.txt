Microsoft Excel VBA & Macros - From Beginner to Advanced
Companion practice files for Part II (Chapters 10-20)

All data in these files is ILLUSTRATIVE and invented for teaching.
It does not represent any real company, person or transaction.

VBA_Book_Practice_Part2.xlsx
  Used in Chapters 10-20. Sheets: ReadMe, Sales (40 orders), Employees (15 staff),
  Inventory (10 products), Invoices (12 invoices), RawData (6 messy customer
  records, stored as text) and Report (blank, for output).
  Before adding code: File > Save As > Excel Macro-Enabled Workbook (*.xlsm),
  for example Chapter14.xlsm, so every chapter starts from the same data.

Check figures: Sales total Rs 363,804.00 (10 orders per region);
Employees monthly CTC Rs 761,500; 8 unpaid invoices worth Rs 277,990.
Examples use a fixed report date of 31-Oct-2026 (constant REPORT_DATE).
