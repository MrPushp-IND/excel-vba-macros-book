Microsoft Excel VBA & Macros - From Beginner to Advanced
Companion practice files for Part I (Chapters 1-9)

All data in these files is ILLUSTRATIVE and invented for teaching.
It does not represent any real company, person or transaction.

VBA_Book_Practice_Part1.xlsx
  Used in Chapters 1-9. Sheets: Ch1_Practice, ReadMe, Sales (20 orders),
  Customers (8 names typed inconsistently), RunLog.
  Before adding code: File > Save As > Excel Macro-Enabled Workbook (*.xlsm).

VBA_Book_Ch09_Supplier_Prices.xlsx
  Used in Chapter 9 (Code 9.2, safe inspection). Sheets: Prices, Terms.
  Keep it closed when you run the inspection macro.
